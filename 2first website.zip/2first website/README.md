# Basic-Website-using-HTML5-CSS3
Create your very first website using HTML5, CSS3

Paste all the images in one folder and name it as img.
Download logo image and paste it in img folder.

copy and paste index.html code in VS Code or NOTE PAD ++ and save it as index.html
copy and paste style.css code in VS Code or NOTE PAD ++ and save it as style.css


-----WILL POST SHOPPING WEBSITE WITH ADD TO CART OPTION AND FULLY FUNCTIONABLE----
